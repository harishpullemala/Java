package com.cg.example;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidateUser{
	public boolean Validation(String user,String pswrd,String mail,String contact, String address)
	{
		
		
		boolean result = false;
		return result;
		
}

public boolean isNameValid(String name) {

		String nameRegEx = "[A-Z]{1}[a-zA-Z]{5,20}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}

	public boolean isPhonevalid(String contact) {

		String phoneregEx = "[0-9]{10}";
		Pattern pattern = Pattern.compile(phoneregEx);
		Matcher matcher = pattern.matcher(String.valueOf(contact));
		return matcher.matches();
	}

	public boolean ismailValid(String problemName) {

		String nameRegEx = "[a-zA-Z]{3,}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(problemName);
		return matcher.matches();
	}
	
	

}
